package com.restaurantbox.host

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(pad, pad * 2, pad, pad)

        status = TextView(this)
        status.textSize = 18f

        val start = Button(this)
        start.text = "Start server"
        start.setOnClickListener {
            startForegroundService(Intent(this, ServerService::class.java))
            status.postDelayed({ refresh() }, 600)
        }

        val stop = Button(this)
        stop.text = "Stop server"
        stop.setOnClickListener {
            stopService(Intent(this, ServerService::class.java))
            status.postDelayed({ refresh() }, 600)
        }

        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val state = if (ServerService.running) "RUNNING" else "STOPPED"
        status.text = "Server: $state\n\nOn another phone connected to the same Wi-Fi, open:\nhttp://${localIp()}:${ServerService.PORT}\n"
    }

    private fun localIp(): String {
        try {
            for (nif in NetworkInterface.getNetworkInterfaces()) {
                for (addr in nif.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address && addr.isSiteLocalAddress) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (e: Exception) {
        }
        return "unknown"
    }
}
