package com.restaurantbox.host

import android.content.res.AssetManager
import fi.iki.elonen.NanoHTTPD
import java.io.IOException

class WebServer(private val assetManager: AssetManager, port: Int) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        var path = session.uri.substringBefore('?')
        if (path == "/") path = "/index.html"
        if (path.contains("..")) {
            return newFixedLengthResponse(Response.Status.FORBIDDEN, MIME_PLAINTEXT, "Forbidden")
        }
        return try {
            val stream = assetManager.open("web$path")
            newChunkedResponse(Response.Status.OK, mimeFor(path), stream)
        } catch (e: IOException) {
            newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
        }
    }

    private fun mimeFor(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "html" -> "text/html; charset=utf-8"
        "css" -> "text/css; charset=utf-8"
        "js" -> "application/javascript; charset=utf-8"
        "json" -> "application/json; charset=utf-8"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "svg" -> "image/svg+xml"
        else -> "application/octet-stream"
    }
}
